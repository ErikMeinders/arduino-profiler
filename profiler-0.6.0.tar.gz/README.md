# arduino-profiler
A very basic set of profiling and timing macros for Arduino
